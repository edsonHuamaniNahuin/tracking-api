<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vessel extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'user_id',
        'name',
        'imo',
        'vessel_type_id',
        'vessel_status_id',
    ];

    protected $with = ['vesselType', 'vesselStatus'];

    protected $hidden = [
        'vessel_type_id',
        'vessel_status_id',
        'deleted_at',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];


    /**
     * Cada Vessel “pertenece a” un User.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }


    /**
     * Relación con el tipo de embarcación.
     */
    public function vesselType()
    {
        return $this->belongsTo(VesselType::class);
    }

    /**
     * Relación con el estado de embarcación.
     */
    public function vesselStatus()
    {
        return $this->belongsTo(VesselStatus::class);
    }

    /**
     * Un Vessel puede tener muchos Trackings.
     */
    public function trackings()
    {
        return $this->hasMany(Tracking::class);
    }

    /**
     * Un Vessel puede tener muchas VesselMetrics.
     */
    public function metrics()
    {
        return $this->hasMany(VesselMetric::class);
    }
}
