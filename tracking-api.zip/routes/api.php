<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\VesselController;
use App\Http\Controllers\Api\TrackingController;
use App\Http\Controllers\Api\UserRoleController;
use App\Http\Controllers\Api\VesselMetricController;
use App\Http\Controllers\Api\VesselStatusController;
use App\Http\Controllers\Api\VesselTypeController;
use App\Http\Controllers\Api\DashboardController;

Route::prefix('v1')->group(function () {
    //
    // Autenticación pública
    //
    Route::post('auth/login',                       [AuthController::class, 'login'])->name('login');

    //
    // Rutas protegidas por JWT
    //
    Route::middleware('auth:api')->group(function () {
        // Perfil de usuario
        Route::get('user',                              [ProfileController::class, 'show']);
        Route::put('user',                              [ProfileController::class, 'update']);
        Route::put('user/password',                     [ProfileController::class, 'changePassword']);
        Route::post('user/notifications/email/enable',  [ProfileController::class, 'enableEmailNotifications']);
        Route::post('user/notifications/email/disable', [ProfileController::class, 'disableEmailNotifications']);
        Route::post('user/notifications/push/enable',   [ProfileController::class, 'enablePushNotifications']);
        Route::post('user/notifications/push/disable',  [ProfileController::class, 'disablePushNotifications']);
        Route::post('user/newsletter/enable',           [ProfileController::class, 'enableNewsletter']);
        Route::post('user/newsletter/disable',          [ProfileController::class, 'disableNewsletter']);
        Route::post('user/2fa/enable',                  [ProfileController::class, 'enableTwoFactor']);
        Route::post('user/2fa/disable',                 [ProfileController::class, 'disableTwoFactor']);
        Route::post('user/profile/public',              [ProfileController::class, 'enablePublicProfile']);
        Route::post('user/profile/private',             [ProfileController::class, 'disablePublicProfile']);
        Route::post('user/online-status/show',          [ProfileController::class, 'showOnlineStatus']);
        Route::post('user/online-status/hide',          [ProfileController::class, 'hideOnlineStatus']);


        // Gestión de roles de un usuario
        Route::post('users/{user}/roles',           [UserRoleController::class, 'assign']);
        Route::delete('users/{user}/roles/{role}',  [UserRoleController::class, 'revoke']);

        // Endpoints de Auth internos
        Route::post('auth/me',                      [AuthController::class, 'me']);
        Route::post('auth/logout',                  [AuthController::class, 'logout']);
        Route::post('auth/refresh',                 [AuthController::class, 'refresh']);



        Route::apiResource('vessels',               VesselController::class);
        Route::get('vessel-metrics',             [VesselMetricController::class, 'index']);
        Route::post('vessel-metrics',            [VesselMetricController::class, 'store']);
        Route::get('vessel-metrics/{metric}',    [VesselMetricController::class, 'show']);
        Route::put('vessel-metrics/{metric}',    [VesselMetricController::class, 'update']);
        Route::delete('vessel-metrics/{metric}', [VesselMetricController::class, 'destroy']);

        // CRUD completo de trackings
        Route::get('trackings/recent', [TrackingController::class, 'recent']);
        Route::apiResource('trackings', TrackingController::class);

        // Listar trackings por embarcación (método alternativo)
        Route::get('vessels/{vessel}/trackings', [TrackingController::class, 'indexByVessel']);

        // Rutas para formularios (estructura completa de modelos)
        Route::get('vessels-types',                  [DashboardController::class, 'getVesselTypesForForms']);
        Route::get('vessels-status',                [DashboardController::class, 'getVesselStatusForForms']);

        // Dashboard métricas
        Route::prefix('dashboard')->group(function () {
            Route::get('metrics',                   [DashboardController::class, 'getMainMetrics']);
            Route::get('vessels-by-type',           [DashboardController::class, 'getVesselsByType']);
            Route::get('vessels-by-status',         [DashboardController::class, 'getVesselsByStatus']);
            Route::get('monthly-activity',          [DashboardController::class, 'getMonthlyActivity']);
            Route::get('fleet-aging',               [DashboardController::class, 'getFleetAging']);
            Route::get('performance-metrics',       [DashboardController::class, 'getPerformanceMetrics']);
            Route::get('vessel-positions',          [DashboardController::class, 'getVesselPositions']);
            Route::get('all-metrics',               [DashboardController::class, 'getAllMetrics']);
        });
    });
});
